#include "rakwireless.h"
#include "Engiro.h"


void LORA::RAKInit() { // Modem Serial Comm Initiate. Mandatory function to be called before all other API functions.
  ComSerial.begin(115200);
}


bool LORA::isModemAvailable() { // Returns true if a valid modem response is received.
	ComSerial.println("AT");
	CS_LORA_RES res = serial_res(500,F("OK"));
	return(res.status);
}


String LORA::getSN() { 			// Displays Serial Number.
	ComSerial.println("AT+SN=?");
	CS_LORA_RES res = serial_res(500,F("OK"));		
	String out = res.temp;
	return (out);
}


String LORA::getARSSI() { 		// Inquiry All Open Channels RSSI.
	ComSerial.println("AT+ARSSI=?");
	CS_LORA_RES res = serial_res(500,F("OK"));		
	String out = res.temp;
	return (out);
}


CS_LORA_RES LORA::serial_res(long timeout,String chk_string) {
	unsigned long pv_ok = millis();
	unsigned long current_ok = millis();
	String input;
	unsigned char until=1;
	unsigned char res=-1;
	CS_LORA_RES res_;
	res_.temp="";
	res_.data="";

	while(until) {
		if(ComSerial.available()) {
			input = ComSerial.readStringUntil('\n');
			res_.temp+=input;
			if(input.indexOf(chk_string)!=-1) {
				res=1;
				until=0;
			} else if(input.indexOf(F("ERROR"))!=-1) {
				res=0;
				until=0;
			}
		}
		current_ok = millis();
		if (current_ok - pv_ok>= timeout) {
			until=0;
			res=0;
			pv_ok = current_ok;
		}
	}
	res_.status = res;
	res_.data = input;
	return(res_);
}