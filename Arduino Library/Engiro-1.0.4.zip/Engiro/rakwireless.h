#include "Arduino.h"

struct CS_LORA_RES {
	unsigned char status;
	String data;
	String temp;
};


class LORA {
  public:
  // Public API Functions starts here.
    void RAKInit(); // Modem Serial Comm Initiate. Mandatory function to be called before all other API functions.
    
  // Network Function Method


  // Get Info/Status methods.
    bool isModemAvailable();  // Returns true if a valid modem response is received.
    String getSN();		        // Displays Serial Number.
    String getARSSI(); 		    // Inquiry All Open Channels RSSI.


  private:
    CS_LORA_RES serial_res(long timeout, String chk_string);
};